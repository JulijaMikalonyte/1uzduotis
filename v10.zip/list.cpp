#include "basic.h"
void ListNuskaitymas(std::list<duomenys>& studentai, int kiek, int kiek_paz, int kaip)
{
	int studento_nr = 0;
	int temp;
	duomenys duom;
	int suma = 0;

	std::ifstream fileRead;
	std::string pavadinimas = "Studentai_" + std::to_string(kiek) + ".txt";
	std::string buff;

	fileRead.open(pavadinimas);

	if (fileRead.is_open()) {
		getline(fileRead >> std::ws, buff);

		auto start = std::chrono::high_resolution_clock::now();

		while (studento_nr < kiek) {

			fileRead >> duom.Vard;
			fileRead >> duom.Pav;

			int suma;
			for (int j = 0; j <= kiek_paz; j++) {
				int w;
				fileRead >> w;
				duom.lpaz.push_back(w);
			}

			for (std::list<int>::iterator it = duom.lpaz.begin(); it != duom.lpaz.end(); ++it) {
				suma += *it;
			}

			fileRead >> duom.egz;

			studento_nr++;
		}

		fileRead >> duom.egz;
		studentai.push_back(duom);


		auto end = std::chrono::high_resolution_clock::now();
		std::chrono::duration<double> diff = end - start;
		std::cout << "\nFailo nuskaitymas su list uztruko: " << std::fixed << diff.count() << " s\n";
	}

	while (studento_nr < kiek)
	{
		if (kaip == 1) {
			duom.GP = suma / kiek;
		}
		else if (kaip == 0) {
			int ilgis;
			duom.lpaz.sort();
			ilgis = duom.lpaz.size();
			if (ilgis % 2 == 0) {
				auto it1 = std::next(duom.lpaz.begin(), ilgis / 2 - 1);
				auto it2 = std::next(duom.lpaz.begin(), ilgis / 2 - 2);
				duom.GP = (*it1 + *it2) / 2;
			}
			else {
				auto it3 = std::next(duom.lpaz.begin(), (ilgis - 1) / 2);
				duom.GP = *it3;
			}
		}
		studento_nr++;
	}

};

void ListRusiavimas1strategija(std::list<duomenys>& studentai, std::list<duomenys>& protingi, std::list<duomenys>& vargsiukai) {

	auto start = std::chrono::high_resolution_clock::now();

	for (duomenys st : studentai)
	{
		if (st.GP < 5)
			vargsiukai.push_back(st);
		else
			protingi.push_back(st);
	}

	auto end = std::chrono::high_resolution_clock::now();
	std::chrono::duration<double> diff = end - start;
	std::cout << "LIST: rusiavimas 1 strategija : " << diff.count() << " s\n";
}

void ListRusiavimas2strategija(std::list<duomenys>& studentai, std::list<duomenys>& protingi, std::list<duomenys>& vargsiukai) {

	auto start = std::chrono::high_resolution_clock::now();

	copy_if(studentai.begin(), studentai.end(), back_inserter(vargsiukai), [](duomenys x) {return x.GP < 5; });
	studentai.erase(remove_if(studentai.begin(), studentai.end(), [](duomenys x) {return x.GP < 5; }), studentai.end());

	auto end = std::chrono::high_resolution_clock::now();
	std::chrono::duration<double> diff = end - start;
	std::cout << "LIST: rusiavimas 2 strategija : " << diff.count() << " s\n\n";
}