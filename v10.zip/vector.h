#pragma once
#include "basic.h"

void VectorNuskaitymas(int kiek, std::vector<duomenys>& Eil, int kiek_paz, int kaip);
void VectorRusiavimas1strategija(int kiek, std::vector<duomenys> VStudentai, std::vector<duomenys> VProtingi, std::vector<duomenys> VVargsiukai);
void VectorRusiavimas2strategija(int kiek, std::vector<duomenys>& VStudentai, std::vector<duomenys>& VProtingi, std::vector<duomenys>& VVargsiukai);

