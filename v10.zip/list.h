#pragma once
#include "basic.h"
void ListNuskaitymas(std::list<duomenys>& studentai, int kiek, int kiek_paz, int kaip);
void ListRusiavimas1strategija(std::list<duomenys>& studentai, std::list<duomenys>& protingi, std::list<duomenys>& vargsiukai);
void ListRusiavimas2strategija(std::list<duomenys>& studentai, std::list<duomenys>& protingi, std::list<duomenys>& vargsiukai);

