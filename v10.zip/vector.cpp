#include "basic.h"
void VectorNuskaitymas(int kiek, std::vector<duomenys>& Eil, int kiek_paz, int kaip) {
	int studento_nr = 0;
	std::ifstream fileRead;
	std::string pavadinimas = "Studentai_" + std::to_string(kiek) + ".txt";
	std::string buff;

	fileRead.open(pavadinimas);
	int suma = 0;

	if (fileRead.is_open()) {
		getline(fileRead >> std::ws, buff);

		auto start = std::chrono::high_resolution_clock::now();

		while (studento_nr < kiek) {
			Eil.resize(Eil.size() + 1);

			fileRead >> Eil.at(studento_nr).Vard;
			fileRead >> Eil.at(studento_nr).Pav;

			for (int j = 0; j <= kiek_paz; j++) {
				int a;
				fileRead >> a;
				Eil.at(studento_nr).paz.push_back(a);

				suma = suma + Eil.at(studento_nr).paz[j];
			}

			fileRead >> Eil.at(studento_nr).egz;
			studento_nr++;
		}

		auto end = std::chrono::high_resolution_clock::now();
		std::chrono::duration<double> diff = end - start;

		std::cout << "Failo nuskaitymas su vector uztruko: " << diff.count() << " s\n";
	}

	

	while (studento_nr < kiek)
	{
		if (kaip == 1) {
			Eil.at(studento_nr).GP = suma / kiek;
		}
		else {
			int z = 0;
			int ilgis;
			ilgis = Eil.at(studento_nr).paz.size();
			while (z < ilgis - 1) {
				for (int i = z + 1; i < ilgis; i++) {
					if (Eil.at(studento_nr).paz[z] < Eil.at(studento_nr).paz[i]) {
						std::swap(Eil.at(studento_nr).paz[z], Eil.at(studento_nr).paz[i]);
					}
				}
				z++;
			}
			if (ilgis % 2 == 0) {
				Eil.at(studento_nr).GP = (Eil.at(studento_nr).paz[ilgis / 2 - 1] + Eil.at(studento_nr).paz[ilgis / 2]) / 2;
			}
			else {
				Eil.at(studento_nr).GP = Eil.at(studento_nr).paz[(ilgis + 1) / 2 - 1];
			}
		}
	}
};

void VectorRusiavimas1strategija(int kiek, std::vector<duomenys> VStudentai, std::vector<duomenys> VProtingi, std::vector<duomenys> VVargsiukai) {

	auto start = std::chrono::high_resolution_clock::now();
	auto st = start;

	for (duomenys st : VStudentai)
	{

		if (st.GP < 5)
			VVargsiukai.push_back(st);
		else
			VProtingi.push_back(st);
	}

	auto end = std::chrono::high_resolution_clock::now();
	std::chrono::duration<double> diff = end - start;
	std::cout << "VECTOR: rusiavimas 1 strategija  : " << std::fixed << diff.count() << " s\n";
};

void VectorRusiavimas2strategija(int kiek, std::vector<duomenys>& VStudentai, std::vector<duomenys>& VProtingi, std::vector<duomenys>& VVargsiukai) {

	auto start = std::chrono::high_resolution_clock::now();
	auto st = start;
	long int sk = 0;

	auto gend = partition(begin(VStudentai), end(VStudentai), [](const auto& x) {return (x.GP >= 5) == 1; });
	VVargsiukai.resize(end(VStudentai) - gend);
	copy(gend, end(VStudentai), begin(VVargsiukai));
	VStudentai.erase(gend, end(VStudentai));

	auto end = std::chrono::high_resolution_clock::now();
	std::chrono::duration<double> diff = end - start;
	std::cout << "VECTOR: rusiavimas 2 strategija : " << std::fixed << diff.count() << " s\n";
};