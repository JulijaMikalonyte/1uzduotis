#include "basic.h"
void ListNuskaitymas(std::list<duomenys>& studentai, int kiek)
{
	int student_counter = 0;
	std::ifstream fileRead;
	std::string pavadinimas = "Studentai_" + std::to_string(kiek) + ".txt";
	std::string buff;

	fileRead.open(pavadinimas);

	if (fileRead.is_open()) {
		getline(fileRead >> std::ws, buff);

		auto start = std::chrono::high_resolution_clock::now();

		while (student_counter < kiek)
		{
			duomenys duom;
			fileRead >> duom.Vard;
			fileRead >> duom.Pav;
			fileRead >> duom.GP;
			studentai.push_back(duom);
			student_counter++;
		}

		auto end = std::chrono::high_resolution_clock::now();
		std::chrono::duration<double> diff = end - start;
		std::cout << "Failo nuskaitymas su list uztruko: " << diff.count() << " s\n";
	}
};

void ListRusiavimas(std::list<duomenys>& studentai, std::list<duomenys>& protingi, std::list<duomenys>& vargsiukai) {
	duomenys Eil;

	auto start = std::chrono::high_resolution_clock::now();

	for (duomenys Eil : studentai) {
		if (Eil.GP < 5) {
			vargsiukai.push_back(Eil);
		}
		else {
			protingi.push_back(Eil);
		}
	}

	auto end = std::chrono::high_resolution_clock::now();
	std::chrono::duration<double> diff = end - start;

	std::cout << "Failo rusiavimas su  i dvi grupes su list uztruko : " << diff.count() << " s\n";
};
