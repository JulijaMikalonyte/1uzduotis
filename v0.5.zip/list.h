#pragma once
#include "basic.h"
void ListNuskaitymas(std::list<duomenys>& studentai, int kiek);
void ListRusiavimas(std::list<duomenys>& studentai, std::list<duomenys>& protingi, std::list<duomenys>& vargsiukai);