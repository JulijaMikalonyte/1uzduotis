#include "basic.h"

void VectorNuskaitymas(int kiek, std::vector<duomenys>& Eil) {
	int studento_nr = 0;
	std::ifstream fileRead;
	std::string pavadinimas = "Studentai_" + std::to_string(kiek) + ".txt";
	std::string buff;

	fileRead.open(pavadinimas);

	auto start = std::chrono::high_resolution_clock::now();
	auto st = start;

	if (fileRead.is_open()) {
		getline(fileRead >> std::ws, buff);
		while (studento_nr < kiek) {
			Eil.resize(Eil.size() + 1);
			fileRead >> Eil.at(studento_nr).Vard;
			fileRead >> Eil.at(studento_nr).Pav;
			fileRead >> Eil.at(studento_nr).GP;
			studento_nr++;
		}
	}

	auto end = std::chrono::high_resolution_clock::now();
	std::chrono::duration<double> diff = end - start;

	std::cout << "Failo nuskaitymas su vector uztruko: " << diff.count() << " s\n";
};

void VectorRusiavimas(int kiek, std::vector<duomenys>& VStudentai, std::vector<duomenys>& VProtingi, std::vector<duomenys>& VVargsiukai) {

	int vargs = 0;
	int prot = 0;

	auto start = std::chrono::high_resolution_clock::now();
	auto st = start;

	for (auto& a : VStudentai) {
		if (a.GP < 5.00)
			VVargsiukai.push_back(a);
		else {
			VProtingi.push_back(a);
		}
	}

	auto end = std::chrono::high_resolution_clock::now();
	std::chrono::duration<double> diff = end - st;

	std::cout << "Failo rusiavimas su  i dvi grupes su vector uztruko : " << std::fixed << diff.count() << " s\n";
};