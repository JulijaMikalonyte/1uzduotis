#include "basic.h"
#include "vector.h"
#include "list.h"

duomenys get(std::list<duomenys> _list, int _i) {
	std::list<duomenys>::iterator it = _list.begin();
	for (int i = 0; i < _i; i++) {
		++it;
	}
	return *it;
};

int main() {

	int kuris;
	std::cout << "Kuri faila norite isrusiuoti?\n 1 - studentai1000.txt\n 2 - studentai10000.txt\n 3 - studentai100000.txt\n 4 - studentai1000000.txt\n 5 - studentai10000000.txt" << std::endl;
	std::cin >> kuris;
	int kiek;
	if (kuris == 1) { kiek = 1000; };
	if (kuris == 2) { kiek = 10000; };
	if (kuris == 3) { kiek = 100000; };
	if (kuris == 4) { kiek = 1000000; };
	if (kuris == 5) { kiek = 10000000; };

	std::list<duomenys> studentai;
	std::list<duomenys> protingi;
	std::list<duomenys> vargsiukai;

	ListNuskaitymas(studentai, kiek);
	ListRusiavimas(studentai, protingi, vargsiukai);

	std::vector<duomenys> VStudentai;
	std::vector<duomenys> VProtingi;
	std::vector<duomenys> VVargsiukai;

	VectorNuskaitymas(kiek, VStudentai);
	VectorRusiavimas(kiek, VStudentai, VProtingi, VVargsiukai);
}