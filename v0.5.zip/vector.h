#pragma once
#include "basic.h"
void VectorNuskaitymas(int kiek, std::vector<duomenys>& Eil);
void VectorRusiavimas(int kiek, std::vector<duomenys>& VStudentai, std::vector<duomenys>& VProtingi, std::vector<duomenys>& VVargsiukai);