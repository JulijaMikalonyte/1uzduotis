#include <string>
#pragma once

unsigned int countWordsInString(std::string const& str);
