#include <vector>
#pragma once

float count_median(std::vector<int> pazymiai);