#pragma once
#include <vector>

double mediana(std::vector<float>& vec);
