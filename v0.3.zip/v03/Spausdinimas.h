#pragma once
#include <vector>
#include "studentas.h"
void Spausdinimas(std::vector<studentas> Eil, int pazymiu_sk);
