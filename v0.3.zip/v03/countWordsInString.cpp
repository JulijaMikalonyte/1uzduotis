#include <string>
#include <iterator>
#include <sstream>
#include <fstream>
#include "countWordsInString.h"

unsigned int countWordsInString(std::string const& str) {
    std::stringstream stream(str);
    return std::distance(std::istream_iterator<std::string>(stream), std::istream_iterator<std::string>());
}