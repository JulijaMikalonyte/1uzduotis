#include <vector>
#include "count_median.h"

float count_median(std::vector<int> pazymiai) { //funkcija suskaiciuoja mediana
    int counter = 0;
    for (int i = 0; i < 10; i++) {
        if (pazymiai[i] != 0) {
            counter++;
        }
        if (pazymiai[i] == -1) {
            pazymiai[i] = 0;
            counter--;
            break;
        }
    }
    if (counter % 2 == 0) {
        return float(((pazymiai[counter / 2 - 1]) + (pazymiai[(counter / 2)])) / 2.0);
    }
    else {
        return float(pazymiai[(counter / 2)]);
    }
}