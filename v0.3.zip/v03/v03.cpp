#include <iostream>
#include <iomanip>
#include <numeric>

#include "count_median.h"
#include "mediana.h"
#include "Spausdinimas.h"
#include "studentas.h"
#include "countWordsInString.h"
#include "Nuskaitymas.h"
#include "Random.h"

int main() {
    std::cout << "Jei norite, kad pazymiai uz namu darbus butu suvesti automatiskai iveskite 1, jei norite pazymius suvesti patys iveskite 2, jei norite pazymius nuskaityti is failo iveskite 3:\n";
    int a;
    std::cin >> a;

    if (a == 3) {
        int pazymiu_sk;
        char temp;
        std::vector<studentas> Eil;
        Nuskaitymas(Eil, &pazymiu_sk);
        Spausdinimas(Eil, pazymiu_sk);
        system("pause");
        return 0;
    }

    std::cout << "Iveskite studentu skaiciu" << std::endl;
    int n;
    std::cin >> n;

    std::vector<studentas> grupe;
    studentas tempas;
    grupe.reserve(n);

    float suma = 0, laik, vid, med;

    for (int i = 0; i < n; i++)//info surinkimas
    {
        std::cout << "Iveskite " << i + 1 << "-jo studento varda:\n";
        std::cin >> tempas.Vardas;

        std::cout << "Iveskite " << i + 1 << "-jo studento pavarde:\n";
        std::cin >> tempas.Pavarde;

        if (a == 1) {//nd atsitiktiniai
            tempas.egzaminas = Random();
            int k = 0;
            while (k < 5) {
                tempas.nd.push_back(Random());
                k = k + 1;
            }
        }
        if (a == 2) {//nd suvesti ranka
            std::cout << "Iveskite studento gautus pazymius uz namu darbus, suvedus visus pazymius ivekite bruksni:\n";

            suma = 0;

            while (std::cin >> laik) {
                tempas.nd.push_back(laik);
                suma = suma + laik;
            }

            std::cin.clear();//ignoruoja bloga ivesti
            std::cin.ignore(10000, '\n');//ignoruoja ivesties paskutini n-taji

            std::cout << "Iveskite " << i + 1 << "-jo studento egzamino pazymi:\n";
            std::cin >> tempas.egzaminas;
        }
        vid = std::accumulate(tempas.nd.begin(), tempas.nd.end(), 0.0) / tempas.nd.size();//acc-susumuoja nuo pirmo iki paskutinio vektoriaus elemento

        med = 0.4 * mediana(tempas.nd) + 0.6 * tempas.egzaminas;
        tempas.medgalutinis = med;

        tempas.galutinis = 0.4 * vid + 0.6 * tempas.egzaminas;
        grupe.push_back(tempas);
        tempas.nd.clear();
    }
    std::cout << "Jei norite, kad studentu galutiniai pazymiai butu suskaiciuoti pagal vidurki, iveskite 1, jei pagal mediana iveskite 2:" << std::endl;
    int pasirinkimas;
    std::cin >> pasirinkimas;

    std::cout << std::setw(15) << "Vardas" << std::setw(15) << "Pavarde" << std::setw(20) << "Galutinis pazymys\n" << "-----------------------------------------------------\n";

    if (pasirinkimas == 1) {
        for (const auto& g : grupe) {
            std::cout << std::setw(15) << g.Vardas << std::setw(15) << g.Pavarde << std::setw(15) << std::setprecision(2) << g.galutinis << std::endl;
        }
    }
    else {
        for (const auto& g : grupe) {
            std::cout << std::setw(15) << g.Vardas << std::setw(15) << g.Pavarde << std::setw(15) << std::setprecision(2) << g.medgalutinis << std::endl;
        }
    }
}