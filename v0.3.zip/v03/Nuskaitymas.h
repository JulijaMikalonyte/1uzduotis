#pragma once
#include "studentas.h"

void Nuskaitymas(std::vector<studentas>& Eil, int* pazymiu_sk);
