#pragma once
#include <vector>
#include <string>

struct studentas {
    std::string Vardas, Pavarde;
    std::vector<float> nd;
    std::vector<int> paz = { 0 };
    float galutinis;//naudijamas vidurkiui apskaiciuot
    float medgalutinis;
    float egzaminas;
};
