#include <thread>

int Random() //sugeneruoja random skaiciu nuo 1 iki 10
{
    srand(time(NULL));
    return rand() % 10 + 1;
}