#include "countWordsInString.h"
#include <vector>
#include "studentas.h"
#include "Nuskaitymas.h"
#include <iostream>
#include <fstream>

void Nuskaitymas(std::vector<studentas>& Eil, int* pazymiu_sk)
{
    int student_counter = 0;
    int temp;
    std::ifstream fileRead;
    std::string buff;
    try {
        fileRead.open("kursiokai.txt");

        if (fileRead.is_open())
            throw 0;

        getline(fileRead >> std::ws, buff);
        *pazymiu_sk = countWordsInString(buff) - 3;

        while (true) {
            Eil.resize(Eil.size() + 1);
            fileRead >> Eil.at(student_counter).Vardas;

            if (fileRead.eof()) { Eil.pop_back(); break; }
            fileRead >> Eil.at(student_counter).Pavarde;
            for (int i = 0; i < *pazymiu_sk; i++) {
                fileRead >> temp;
                Eil.at(student_counter).paz.push_back(temp);
            }
            fileRead >> Eil.at(student_counter).egzaminas;

            Eil.at(student_counter).galutinis = Eil.at(student_counter).galutinis / *pazymiu_sk;
            Eil.at(student_counter).galutinis = Eil.at(student_counter).galutinis * 0.4 + 0.6 * Eil.at(student_counter).egzaminas;
            student_counter++;
            fileRead.close();
            std::cout << "\nApskaiciuoti studentu rezultatai pateikti atskirame rezultatai.txt faile\n\n";
        }
    }
    catch (int e) {
    std::cout << "Neteisingai ivestas failo pavadinimas " << e << std::endl;
    }
}
