#pragma once
int Random();
