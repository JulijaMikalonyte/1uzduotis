#include "basic.h"
void VectorNuskaitymas(int kiek, std::vector<duomenys>& Eil) {
	int studento_nr = 0;
	std::ifstream fileRead;
	std::string pavadinimas = "Studentai_" + std::to_string(kiek) + ".txt";
	std::string buff;

	fileRead.open(pavadinimas);

	auto start = std::chrono::high_resolution_clock::now();
	auto st = start;

	if (fileRead.is_open()) {
		getline(fileRead >> std::ws, buff);
		while (studento_nr < kiek) {
			Eil.resize(Eil.size() + 1);
			fileRead >> Eil.at(studento_nr).Vard;
			fileRead >> Eil.at(studento_nr).Pav;
			fileRead >> Eil.at(studento_nr).GP;
			studento_nr++;
		}
	}

	auto end = std::chrono::high_resolution_clock::now();
	std::chrono::duration<double> diff = end - start;

	std::cout << "Failo nuskaitymas su vector uztruko: " << diff.count() << " s\n";
};

void VectorRusiavimas1strategija(int kiek, std::vector<duomenys> VStudentai, std::vector<duomenys> VProtingi, std::vector<duomenys> VVargsiukai) {

	auto start = std::chrono::high_resolution_clock::now();
	auto st = start;

	for (duomenys st : VStudentai)
	{

		if (st.GP < 5)
			VVargsiukai.push_back(st);
		else
			VProtingi.push_back(st);
	}

	auto end = std::chrono::high_resolution_clock::now();
	std::chrono::duration<double> diff = end - start;
	std::cout << "VECTOR: rusiavimas 1 strategija  : " << std::fixed << diff.count() << " s\n";
};

void VectorRusiavimas2strategija(int kiek, std::vector<duomenys>& VStudentai, std::vector<duomenys>& VProtingi, std::vector<duomenys>& VVargsiukai) {

	auto start = std::chrono::high_resolution_clock::now();
	auto st = start;
	long int sk = 0;

	for (auto& i : VStudentai) {

		if (i.GP < 5) {
			VVargsiukai.push_back(i);
			VStudentai.erase(VStudentai.begin() + sk);
		}
		sk++;
	}

	auto end = std::chrono::high_resolution_clock::now();
	std::chrono::duration<double> diff = end - start;
	std::cout << "VECTOR: rusiavimas 2 strategija : " << std::fixed << diff.count() << " s\n";
};