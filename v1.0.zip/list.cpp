#include "basic.h"
void ListNuskaitymas(std::list<duomenys>& studentai, int kiek)
{
	int student_counter = 0;
	std::ifstream fileRead;
	std::string pavadinimas = "Studentai_" + std::to_string(kiek) + ".txt";
	std::string buff;
	fileRead.open(pavadinimas);
	if (fileRead.is_open()) {
		getline(fileRead >> std::ws, buff);

		auto start = std::chrono::high_resolution_clock::now();

		while (student_counter < kiek) {
			duomenys duom;
			fileRead >> duom.Vard;
			fileRead >> duom.Pav;
			fileRead >> duom.GP;
			studentai.push_back(duom);
			student_counter++;
		}

		auto end = std::chrono::high_resolution_clock::now();
		std::chrono::duration<double> diff = end - start;
		std::cout << "\nFailo nuskaitymas su list uztruko: " << diff.count() << " s\n";
	}
};

void ListRusiavimas1strategija(std::list<duomenys>& studentai, std::list<duomenys>& protingi, std::list<duomenys>& vargsiukai) {

	auto start = std::chrono::high_resolution_clock::now();

	for (duomenys st : studentai)
	{
		if (st.GP < 5)
			vargsiukai.push_back(st);
		else
			protingi.push_back(st);
	}

	auto end = std::chrono::high_resolution_clock::now();
	std::chrono::duration<double> diff = end - start;
	std::cout << "LIST: rusiavimas 1 strategija : " << diff.count() << " s\n";
}

void ListRusiavimas2strategija(std::list<duomenys>& studentai, std::list<duomenys>& protingi, std::list<duomenys>& vargsiukai) {

	auto start = std::chrono::high_resolution_clock::now();

	copy_if(studentai.begin(), studentai.end(), back_inserter(vargsiukai), [](duomenys x) {return x.GP < 5; });
	studentai.erase(remove_if(studentai.begin(), studentai.end(), [](duomenys x) {return x.GP < 5; }), studentai.end());

	auto end = std::chrono::high_resolution_clock::now();
	std::chrono::duration<double> diff = end - start;
	std::cout << "LIST: rusiavimas 2 strategija : " << diff.count() << " s\n\n";
}