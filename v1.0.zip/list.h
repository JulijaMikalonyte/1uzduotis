#pragma once
#include "basic.h"
void ListNuskaitymas(std::list<duomenys>& studentai, int kiek);
void ListRusiavimas1strategija(std::list<duomenys>& studentai, std::list<duomenys>& protingi, std::list<duomenys>& vargsiukai);
void ListRusiavimas2strategija(std::list<duomenys>& studentai, std::list<duomenys>& protingi, std::list<duomenys>& vargsiukai);

